package com.example.androideatit;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Chatting extends AppCompatActivity {

    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    TextView user;
    EditText write;
    Button sendBtn;
    ArrayAdapter adapter;
    String userId, hostId, root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatting);


        Intent intent = getIntent();

        userId = intent.getStringExtra("user");
        hostId = intent.getStringExtra("host");
        root = compareTo(hostId, userId) + "_chat";


        user = (TextView) findViewById(R.id.textView);
        user.setText(userId);


        final ListView listView = (ListView) findViewById(R.id.listView2);
        write = (EditText) findViewById(R.id.writeEdit);
        sendBtn = (Button) findViewById(R.id.send);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, android.R.id.text1);
        listView.setAdapter(adapter);

        showChatContents(root);


    }

    void sendBtn(View v) {
        EditText write = (EditText) findViewById(R.id.writeEdit);
        ChatData chatData = new ChatData();
        chatData.setHost(hostId);
        chatData.setUser(userId);
        chatData.setMessage(write.getText().toString());
        chatData.setIsHost(true);
        databaseReference.child("chat_relation").push().setValue(chatData);
        write.setText("");
    }

    void showChatContents(String root) {

        //user.setText(root);
        databaseReference.child(root).addChildEventListener(new ChildEventListener() {  // message는 child의 이벤트를 수신합니다.
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                ChatData chatData = dataSnapshot.getValue(ChatData.class);
                if (chatData.getIsHost()) {
                    adapter.add(chatData.getHost() + " : " + chatData.getMessage());
                }else {
                    adapter.add(chatData.getUser() + " : " + chatData.getMessage());
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public String compareTo(String host, String user) {
        if (host.compareTo(user) >= 0)
            return host + user;
        return user + host;
    }
}
