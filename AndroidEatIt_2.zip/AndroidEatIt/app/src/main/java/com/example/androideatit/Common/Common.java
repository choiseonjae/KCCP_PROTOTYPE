package com.example.androideatit.Common;

import com.example.androideatit.Model.User;

public class Common {
    public static User currentUser;
}
